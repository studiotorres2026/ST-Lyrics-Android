const $ = id => document.getElementById(id);
const canvas = $("preview"), ctx = canvas.getContext("2d"), audio = $("audio");
let background = null, timings = [], currentLines = [];
const defaults = {title:"ST Lyrics",artist:"Studio Torres"};
function lines(){return $("lyrics").value.split(/\r?\n/).map(s=>s.trim()).filter(Boolean)}
function refreshLineSelect(){
  currentLines=lines(); const sel=$("lineSelect"); sel.innerHTML="";
  currentLines.forEach((line,i)=>{const o=document.createElement("option");o.value=i;o.textContent=(i+1)+". "+line;sel.appendChild(o)});
  if(!currentLines.length){const o=document.createElement("option");o.textContent="Primero escribe las letras";o.value="";sel.appendChild(o)}
  draw();
}
function activeLyric(){
  if(!currentLines.length)return "";
  if(timings.length){
    const ordered=[...timings].sort((a,b)=>a.time-b.time);
    let found=null; for(const t of ordered){if(audio.currentTime>=t.time)found=t;else break}
    return found ? currentLines[found.index] || "" : "";
  }
  const idx=Math.min(currentLines.length-1,Math.floor((audio.currentTime/5)%currentLines.length));
  return currentLines[idx]||"";
}
function draw(){
  const w=canvas.width,h=canvas.height;
  ctx.clearRect(0,0,w,h);
  if(background){
    const scale=Math.max(w/background.width,h/background.height),sw=background.width*scale,sh=background.height*scale;
    ctx.drawImage(background,(w-sw)/2,(h-sh)/2,sw,sh);
  }else{
    const g=ctx.createLinearGradient(0,0,w,h);g.addColorStop(0,"#142b49");g.addColorStop(1,"#030812");ctx.fillStyle=g;ctx.fillRect(0,0,w,h);
    ctx.fillStyle="#d9b45d";ctx.font="bold 72px Arial";ctx.textAlign="center";ctx.fillText("ST LYRICS",w/2,h/2-20);
    ctx.fillStyle="#ffffff";ctx.font="34px Arial";ctx.fillText("Studio Torres",w/2,h/2+45);
  }
  ctx.fillStyle="rgba(0,0,0,.28)";ctx.fillRect(0,0,w,h);
  const title=$("songTitle").value||defaults.title,artist=$("artist").value||defaults.artist;
  ctx.textAlign="center";ctx.fillStyle="#fff";ctx.shadowColor="#000";ctx.shadowBlur=12;
  ctx.font="bold 54px Arial";ctx.fillText(title,w/2,100, w-100);
  ctx.font="32px Arial";ctx.fillText(artist,w/2,150,w-100);
  const lyric=activeLyric();
  const size=Number($("fontSize").value)||64;ctx.font="bold "+size+"px Arial";
  ctx.fillStyle=$("textColor").value||"#fff";
  const pos=$("position").value;let y=pos==="top"?260:pos==="center"?h/2:h-190;
  if(lyric){
    ctx.lineWidth=8;ctx.strokeStyle="rgba(0,0,0,.8)";ctx.strokeText(lyric,w/2,y,w-140);ctx.fillText(lyric,w/2,y,w-140);
  } else if(currentLines.length){
    ctx.font="38px Arial";ctx.fillStyle="#fff";ctx.fillText("Pulsa reproducir para ver tus letras",w/2,h-190,w-120);
  }
  ctx.shadowBlur=0;
}
$("bgFile").addEventListener("change",e=>{
  const f=e.target.files[0];if(!f)return;const url=URL.createObjectURL(f),img=new Image();
  img.onload=()=>{background=img;draw();$("status").textContent="Fondo cargado. Los cambios aparecen en la vista previa.";};img.src=url;
});
$("audioFile").addEventListener("change",e=>{const f=e.target.files[0];if(!f)return;audio.src=URL.createObjectURL(f);$("status").textContent="Canción cargada. Pulsa reproducir.";});
["songTitle","artist","lyrics","textColor","fontSize","position"].forEach(id=>{
  $(id).addEventListener("input",()=>{if(id==="lyrics")refreshLineSelect();else draw()});
  $(id).addEventListener("change",draw);
});
$("playBtn").onclick=()=>audio.play().catch(()=>{$("status").textContent="Primero carga una canción."});
$("pauseBtn").onclick=()=>audio.pause();
$("resetBtn").onclick=()=>{audio.pause();audio.currentTime=0;draw()};
audio.addEventListener("timeupdate",draw);audio.addEventListener("seeked",draw);
$("markBtn").onclick=()=>{
  const idx=Number($("lineSelect").value);
  if(!currentLines.length||$("lineSelect").value===""){$("status").textContent="Primero escribe tus letras.";return}
  timings=timings.filter(t=>t.index!==idx);timings.push({index:idx,time:audio.currentTime});
  timings.sort((a,b)=>a.time-b.time);renderTimes();draw();
  $("status").textContent="Tiempo marcado en "+audio.currentTime.toFixed(2)+" segundos.";
};
$("clearTimes").onclick=()=>{timings=[];renderTimes();draw();$("status").textContent="Sincronización borrada."};
function renderTimes(){
  $("timingList").innerHTML=timings.length?timings.map(t=>`<div class="timeitem">${t.time.toFixed(2)} s — ${escapeHtml(currentLines[t.index]||"Frase")}</div>`).join(""):"<p class='hint'>Todavía no has marcado tiempos.</p>";
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
refreshLineSelect();renderTimes();draw();