const $ = id => document.getElementById(id);
const audio = $("audio"), canvas = $("preview"), ctx = canvas.getContext("2d");
let bg = null, audioUrl = null, bgUrl = null, phrases = [], currentPhrase = 0, raf = 0;
let audioCtx = null, sourceNode = null;

function fmt(s){if(!Number.isFinite(s))s=0;let m=Math.floor(s/60),sec=Math.floor(s%60);return String(m).padStart(2,"0")+":"+String(sec).padStart(2,"0")}
function setStatus(t){$("status").textContent=t}
function wrapText(text,maxWidth,font){ctx.font=font;let words=text.split(/\s+/),lines=[],line="";for(const w of words){let test=line?line+" "+w:w;if(ctx.measureText(test).width>maxWidth&&line){lines.push(line);line=w}else line=test}if(line)lines.push(line);return lines}
function draw(){
 const w=canvas.width,h=canvas.height;
 ctx.clearRect(0,0,w,h);
 if(bg){let scale=Math.max(w/bg.width,h/bg.height),dw=bg.width*scale,dh=bg.height*scale;ctx.drawImage(bg,(w-dw)/2,(h-dh)/2,dw,dh)}
 else {let g=ctx.createLinearGradient(0,0,w,h);g.addColorStop(0,"#14243a");g.addColorStop(.55,"#263d57");g.addColorStop(1,"#080f1c");ctx.fillStyle=g;ctx.fillRect(0,0,w,h);
   ctx.save();ctx.globalAlpha=.18;for(let i=0;i<7;i++){ctx.fillStyle=i%2?"#d8c18b":"#91a9bf";ctx.beginPath();ctx.ellipse(250+i*260,220+(i%3)*65,330,95,0,0,Math.PI*2);ctx.fill()}ctx.restore();}
 const shade=ctx.createLinearGradient(0,h*.52,0,h);shade.addColorStop(0,"rgba(0,0,0,0)");shade.addColorStop(1,"rgba(0,0,0,.78)");ctx.fillStyle=shade;ctx.fillRect(0,0,w,h);
 const title=$("songTitle").value.trim(),artist=$("artist").value.trim();
 ctx.textAlign="center";ctx.fillStyle="#e7c779";ctx.font="bold 38px Arial";ctx.fillText(title.toUpperCase(),w/2,95);
 ctx.fillStyle="rgba(255,255,255,.9)";ctx.font="26px Arial";ctx.fillText(artist,w/2,140);
 let active=-1;
 if(phrases.length){for(let i=0;i<phrases.length;i++){if(phrases[i].time!=null&&audio.currentTime>=phrases[i].time)active=i}}
 let text=active>=0?phrases[active].text:"";
 if(text){let font="bold 66px Arial",lines=wrapText(text,w-220,font);ctx.font=font;ctx.textAlign="center";ctx.lineWidth=8;ctx.strokeStyle="rgba(0,0,0,.85)";ctx.fillStyle="#fff";let start=h-190-(lines.length-1)*82;lines.forEach((ln,i)=>{ctx.strokeText(ln,w/2,start+i*82);ctx.fillText(ln,w/2,start+i*82)})}
 else {ctx.fillStyle="rgba(255,255,255,.82)";ctx.font="bold 48px Arial";ctx.fillText("LETRA SINCRONIZADA",w/2,h-155)}
 ctx.fillStyle="#e7c779";ctx.font="24px Arial";ctx.fillText("STUDIO TORRES",w/2,h-48);
 if(audio.duration){$("progress").style.width=(audio.currentTime/audio.duration*100)+"%";$("timeLabel").textContent=fmt(audio.currentTime)+" / "+fmt(audio.duration)}
 renderLines(active);
 raf=requestAnimationFrame(draw);
}
function renderLines(active=-1){
 const el=$("lines");if(!phrases.length){el.innerHTML="";return}
 el.innerHTML=phrases.map((p,i)=>`<div class="line ${i===active?"active":""}"><span>${i+1}. ${escapeHtml(p.text)}</span><span>${p.time==null?"—":fmt(p.time)}</span></div>`).join("");
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
$("audioFile").addEventListener("change",e=>{let f=e.target.files[0];if(!f)return;if(audioUrl)URL.revokeObjectURL(audioUrl);audioUrl=URL.createObjectURL(f);audio.src=audioUrl;audio.load();$("playBtn").disabled=false;$("pauseBtn").disabled=false;setStatus("Audio cargado: "+f.name);});
audio.addEventListener("loadedmetadata",()=>{$("timeLabel").textContent=fmt(0)+" / "+fmt(audio.duration);});
$("bgFile").addEventListener("change",e=>{let f=e.target.files[0];if(!f)return;if(bgUrl)URL.revokeObjectURL(bgUrl);bgUrl=URL.createObjectURL(f);let im=new Image();im.onload=()=>{bg=im;setStatus("Fondo cargado.")};im.src=bgUrl;});
$("playBtn").onclick=()=>audio.play().catch(()=>setStatus("No se pudo reproducir el audio."));
$("pauseBtn").onclick=()=>audio.pause();
$("prepareBtn").onclick=()=>{phrases=$("lyrics").value.split(/\n/).map(x=>x.trim()).filter(Boolean).map(text=>({text,time:null}));currentPhrase=0;$("markBtn").disabled=!phrases.length;$("backBtn").disabled=!phrases.length;$("resetBtn").disabled=!phrases.length;renderLines();setStatus(phrases.length?phrases.length+" frases preparadas. Reproduce y marca cada frase.":"Escribe la letra, una frase por línea.");};
$("markBtn").onclick=()=>{if(!phrases.length||currentPhrase>=phrases.length)return;if(!audio.src){setStatus("Primero selecciona el audio.");return}phrases[currentPhrase].time=audio.currentTime;currentPhrase++;renderLines();if(currentPhrase>=phrases.length){setStatus("¡Todas las frases tienen tiempo! Puedes revisar y exportar.");$("markBtn").disabled=true}else setStatus("Frase "+currentPhrase+" marcada. Sigue con la siguiente.");};
$("backBtn").onclick=()=>{if(currentPhrase>0){currentPhrase--;phrases[currentPhrase].time=null;$("markBtn").disabled=false;renderLines();setStatus("Puedes volver a marcar la frase "+(currentPhrase+1)+".")}};
$("resetBtn").onclick=()=>{phrases.forEach(p=>p.time=null);currentPhrase=0;$("markBtn").disabled=!phrases.length;renderLines();setStatus("Marcas reiniciadas.")};
function activeText(){let a=-1;for(let i=0;i<phrases.length;i++){if(phrases[i].time!=null&&audio.currentTime>=phrases[i].time)a=i}return a}
function mimeType(){const opts=["video/webm;codecs=vp9,opus","video/webm;codecs=vp8,opus","video/webm"];return opts.find(x=>window.MediaRecorder&&MediaRecorder.isTypeSupported(x))||""}
$("exportBtn").onclick=async()=>{
 if(!audio.src||!phrases.length){setStatus("Carga una canción y prepara la letra.");return}
 if(!phrases.some(p=>p.time!=null)){setStatus("Primero sincroniza al menos una frase.");return}
 if(!("MediaRecorder" in window)||!canvas.captureStream){setStatus("Este navegador no permite exportar video. Prueba con Chrome actualizado.");return}
 const type=mimeType();if(!type){setStatus("No se encontró un formato de grabación compatible.");return}
 $("exportBtn").disabled=true;$("exportInfo").textContent="Preparando video 1080p…";
 try{
  audio.pause();audio.currentTime=0;
  audioCtx=audioCtx||new (window.AudioContext||window.webkitAudioContext)();
  if(!sourceNode){sourceNode=audioCtx.createMediaElementSource(audio)}
  const dest=audioCtx.createMediaStreamDestination();sourceNode.connect(dest);sourceNode.connect(audioCtx.destination);
  await audioCtx.resume();
  const videoStream=canvas.captureStream(30),stream=new MediaStream([...videoStream.getVideoTracks(),...dest.stream.getAudioTracks()]);
  const recorder=new MediaRecorder(stream,{mimeType:type,videoBitsPerSecond:8000000,audioBitsPerSecond:192000});
  const chunks=[];recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)};
  recorder.onstop=()=>{const blob=new Blob(chunks,{type:"video/webm"});const url=URL.createObjectURL(blob);const a=$("download");a.href=url;a.download="ST-Lyrics-Nueva-Alabanza-1080p.webm";a.hidden=false;a.textContent="⬇ Descargar video terminado";$("exportInfo").textContent="Video listo. Formato WebM · 1920 × 1080. El tamaño depende de la duración."; $("exportBtn").disabled=false;stream.getTracks().forEach(t=>t.stop());};
  recorder.start(1000);await audio.play();
  audio.onended=()=>{if(recorder.state!=="inactive")recorder.stop();};
  setStatus("Grabando video. No cierres la aplicación…");
 }catch(err){$("exportBtn").disabled=false;$("exportInfo").textContent="No se pudo exportar: "+err.message;setStatus("Intenta nuevamente con Chrome actualizado.");}
};
audio.addEventListener("ended",()=>{if($("exportBtn").disabled&&$("exportInfo").textContent.includes("Preparando")){}});
$("exportBtn").disabled=false;
draw();
if("serviceWorker" in navigator && location.protocol.startsWith("http"))navigator.serviceWorker.register("sw.js").catch(()=>{});
